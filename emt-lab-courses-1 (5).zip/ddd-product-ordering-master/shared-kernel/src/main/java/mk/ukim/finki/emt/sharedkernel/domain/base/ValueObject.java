package mk.ukim.finki.emt.sharedkernel.domain.base;

public interface ValueObject extends DomainObject {
}
