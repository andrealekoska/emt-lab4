package mk.ukim.finki.emt.sharedkernel.domain.financial;

public enum Currency {
    EUR, USD, MKD
}
