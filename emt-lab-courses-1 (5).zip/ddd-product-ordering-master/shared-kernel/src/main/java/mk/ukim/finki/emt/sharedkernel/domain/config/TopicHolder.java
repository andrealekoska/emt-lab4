package mk.ukim.finki.emt.sharedkernel.domain.config;

public class TopicHolder {
    public final static String TOPIC_ORDER_ITEM_CREATED = "order-item-created";
    public final static String TOPIC_ORDER_ITEM_REMOVED = "order-item-removed";
}
