package mk.ukim.finki.emt.sharedkernel.domain.base;

import java.io.Serializable;

public interface DomainObject extends Serializable {
}
