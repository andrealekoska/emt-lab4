package mk.ukim.finki.emt.ordermanagement.domain.exceptions;

public class OrderItemIdNotExistException extends RuntimeException{
}
