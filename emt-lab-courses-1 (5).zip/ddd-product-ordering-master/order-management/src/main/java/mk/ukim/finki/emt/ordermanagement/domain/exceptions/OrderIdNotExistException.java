package mk.ukim.finki.emt.ordermanagement.domain.exceptions;

public class OrderIdNotExistException extends RuntimeException{
}
