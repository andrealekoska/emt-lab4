package mk.ukim.finki.emt.clientmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
