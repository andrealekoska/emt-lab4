package mk.ukim.finki.emt.clientmanagement.domain.exceptions;

public class ClientIdNotExistException extends RuntimeException{
}
