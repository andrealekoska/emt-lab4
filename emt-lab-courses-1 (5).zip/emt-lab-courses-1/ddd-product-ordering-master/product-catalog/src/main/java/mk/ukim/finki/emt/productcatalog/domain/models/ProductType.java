package mk.ukim.finki.emt.productcatalog.domain.models;

public enum ProductType {
    maski, zenski
}
