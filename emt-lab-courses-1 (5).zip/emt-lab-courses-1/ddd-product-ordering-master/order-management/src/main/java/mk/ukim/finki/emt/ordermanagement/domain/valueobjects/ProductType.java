package mk.ukim.finki.emt.ordermanagement.domain.valueobjects;

public enum ProductType {
    maski, zenski
}
