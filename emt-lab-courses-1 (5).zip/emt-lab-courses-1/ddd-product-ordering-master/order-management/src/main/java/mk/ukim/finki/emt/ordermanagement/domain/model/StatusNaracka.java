package mk.ukim.finki.emt.ordermanagement.domain.model;

public enum StatusNaracka {
    RECEIVED, PROCESSING, CANCELLED
}
