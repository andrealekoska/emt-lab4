package mk.ukim.finki.clientmanagement.clientmanagement1.domain.exceptions;

public class ClientIdNotExistException extends RuntimeException{
}
